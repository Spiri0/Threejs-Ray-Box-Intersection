import {entity} from './entity.js';
import {THREE, ShaderPass, FXAAShader} from './three-defs.js';
import {cloud_model} from './cloud-model.js';
import { cloudsVS } from "../resources/shader/cloudsVS.js";
import { cloudsFS } from "../resources/shader/cloudsFS.js";



export const clouds = (() => {

	class Clouds extends entity.Component {
		constructor(params){
			super();
			this.Init(params);
		}	
	
		Init(params){
			this.params_ = params;
	
			let source = this.params_.threejs;
		
			const clouds = "./resources/textures/clouds/clouds_2.jpg";
			const cloudmodel = new cloud_model.CloudModel({
				renderer: source.threejs_,
				clouds: clouds
			});

			this.sunDir = new THREE.Vector3(-1, 0, 0.5);
			this.sunDir.normalize();
			this.sunDist = 200E9;
			this.sunPos = this.sunDir.multiplyScalar(this.sunDist);
			const logDepthBufFC = 2.0 / ( Math.log(source.depthCamera_.far + 1.0) / Math.LN2);
			
			let uniform = {			
				tDiffuse: { value: null },
				tDepth: { value: null },
				logDepthBufFC: { value: logDepthBufFC },
				planetRadius: { value: 6350000 },
				cloudsInnerRadius: { value: 6356000 },
				cloudsOuterRadius: { value: 6371000 },		
				oceanRadius: { value: null },
				cameraNear: { value: source.depthCamera_.near },
				cameraFar: { value: source.depthCamera_.far },
				cameraPos: { value: source.depthCamera_.position },
				cameraForward: { value: null },
				inverseProjection: { value: null },
				inverseView: { value: null },
				planetPos: { value: null },
				sunColor: { value: null },
				sunPos: { value: this.sunPos },
				cloud: { value: cloudmodel.cloud},   
				worley: { value: cloudmodel.worley},   
				weather: { value: cloudmodel.weather},
			};

			this.clouds = new THREE.RawShaderMaterial({
				glslVersion: THREE.GLSL3,
				uniforms: uniform,
				vertexShader: cloudsVS,
				fragmentShader: cloudsFS,
			});			

			source.composer_.addPass(new ShaderPass(this.clouds));		
		}
		
		
	
		Update(_) {
		
			let source = this.params_.threejs;
			const forward = new THREE.Vector3();
			source.depthCamera_.getWorldDirection(forward);
			
			this.clouds.uniforms.tDepth.value = source.target_.depthTexture;
			this.clouds.uniforms.planetPos.value = new THREE.Vector3(0, 0, 0);
			this.clouds.uniforms.cameraForward.value = forward;
			this.clouds.uniforms.inverseProjection.value = source.depthCamera_.projectionMatrixInverse;
			this.clouds.uniforms.inverseView.value = source.depthCamera_.matrixWorld;
			this.clouds.uniforms.cameraNear.value = source.depthCamera_.near;
			this.clouds.uniforms.cameraFar.value = source.depthCamera_.far;
			this.clouds.uniforms.cameraPos.value = source.depthCamera_.position;
			this.clouds.uniforms.sunColor.value = new THREE.Vector3(1.0, 1.0, 1.0);	
			this.clouds.uniforms.sunPos.value = this.sunPos;	
			this.clouds.uniformsNeedUpdate = true;	
				
		}//end Update
	
	}


return {
	Clouds: Clouds
}

})();