import {THREE, OrbitControls, RenderPass, ShaderPass, EffectComposer, CopyShader, FXAAShader, WebGL} from './three-defs.js';
import {entity} from "./entity.js";


export const threejs_component = (() => {

	class ThreeJSController extends entity.Component {
		constructor() {
			super();
		}

		InitEntity() {
    	
    		if (!WebGL.isWebGL2Available()) {
    			return false;
			}
	
			const canvas = document.createElement('canvas');
			const context = canvas.getContext('webgl2');
		
			this.threejs_ = new THREE.WebGLRenderer({ 
				canvas: canvas,
				context: context,
				antialias: true
			});
    	
			this.threejs_.outputEncoding = THREE.sRGBEncoding;
			this.threejs_.setPixelRatio(window.devicePixelRatio);
			this.threejs_.shadowMap.enabled = true;
			this.threejs_.shadowMap.type = THREE.PCFSoftShadowMap;
			this.threejs_.physicallyCorrectLights = true;
			this.threejs_.domElement.id = 'threejs';
				
			this.container = document.getElementById('container');
			this.threejs_.setSize(this.container.clientWidth, this.container.clientHeight);
			this.container.appendChild( this.threejs_.domElement );
	
			const aspect = this.container.clientWidth / this.container.clientHeight; 
			const fov = 50;
			const near = 1;
			const far = 1E6;
			this.camera_ = new THREE.PerspectiveCamera(fov, aspect, near, far);
			this.scene_ = new THREE.Scene();
			this.threejs_.setClearColor( 0x000000 );
				
			
			this.camera_.position.set(0, 0, 10000);
			
	
			this.fxaaPass = new ShaderPass( FXAAShader );

			var pixelRatio = this.threejs_.getPixelRatio();

			this.fxaaPass.material.uniforms[ 'resolution' ].value.x = 1 / ( this.container.clientWidth * pixelRatio );
			this.fxaaPass.material.uniforms[ 'resolution' ].value.y = 1 / ( this.container.clientHeight * pixelRatio );
					
			this.composer_ = new EffectComposer(this.threejs_);
			const renderPass = new RenderPass(this.scene_, this.camera_);
			this.composer_.addPass(renderPass);
			this.composer_.addPass(this.fxaaPass);
		
		
			
			this.resolution_ = new THREE.Vector2(); 
			this.threejs_.getDrawingBufferSize(this.resolution_);

			this.target_ = new THREE.WebGLRenderTarget(this.resolution_.x, this.resolution_.y);		
			this.target_.stencilBuffer = false;
			this.target_.depthBuffer = true;
			this.target_.depthTexture = new THREE.DepthTexture();
			this.target_.depthTexture.format = THREE.DepthFormat;
			this.target_.depthTexture.type = THREE.FloatType;		
			this.target_.depthTexture.minFilter = THREE.NearestFilter;
			this.target_.depthTexture.magFilter = THREE.NearestFilter;
	
	
			window.addEventListener('resize', () => {this.OnResize_();}, false);
		}//end init	
	

		Render() {

			this.threejs_.setRenderTarget(this.target_);
			this.threejs_.render(this.scene_, this.camera_);   
			this.threejs_.setRenderTarget( null );

			this.composer_.render();

		}


		Update(timeElapsed) {
			const player = this.FindEntity('player');
			if (!player) {
				return;
			}
			const pos = player._position; 

		}
    
    
		OnResize_() {
		
			let width, height;
		
			if(window.innerWidth > window.innerHeight){	
				width = 1.0 * window.innerWidth;
				height = 1.0 * window.innerHeight;				
			}		
			if(window.innerHeight > window.innerWidth){	
				width = 1.0 * window.innerWidth;
				height = 1.0 * window.innerHeight;				
			}
			
			this.camera_.aspect = width / height;
			this.camera_.updateProjectionMatrix();
    		
			this.threejs_.setSize(width, height);
			
			var pixelRatio = this.threejs_.getPixelRatio();

			this.fxaaPass.material.uniforms[ 'resolution' ].value.x = 1 / ( this.container.clientWidth * pixelRatio );
			this.fxaaPass.material.uniforms[ 'resolution' ].value.y = 1 / ( this.container.clientHeight * pixelRatio );
			
		}
  
  }//end class


  return {
      ThreeJSController: ThreeJSController,
  };
})();