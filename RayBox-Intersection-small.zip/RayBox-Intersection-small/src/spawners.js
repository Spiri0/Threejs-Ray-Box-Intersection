import {THREE} from './three-defs.js';

import {entity} from './entity.js';
import {third_person_camera} from './third-person-camera.js';
import {render_component} from './render-component.js';
import {player_controller} from './player-controller.js';
import {player_input} from './player-input.js';


export const spawners = (() => {

	class PlayerSpawner extends entity.Component {
		constructor(params) {
			super();
			this.params_ = params;    
		}

		Spawn() {
			
			const params = {
				camera: this.params_.camera,
				depthCamera: this.params_.depthCamera,
				scene: this.params_.scene,
				offset: new THREE.Vector3(0, 0, 0),
			};

			const player = new entity.Entity();
			player.SetPosition(new THREE.Vector3(0, 0, 10353000));
		
      	player.AddComponent(new render_component.RenderComponent({
      		scene: params.scene,
      		resourcePath: '-',
        	resourceName: '-',
      		scale: 1,
      		layer: 0,
      		offset: {
      			position: new THREE.Vector3(0, 0, 0),
      			quaternion: new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3( 0, 1, 0 ), Math.PI),
      		},
      	}));  
    		
      	player.AddComponent(new player_input.PlayerInput());
			player.AddComponent(new player_controller.PlayerController());
      	player.AddComponent(new third_person_camera.ThirdPersonCamera({
      		camera: this.params_.camera,
      		depthCamera: this.params_.depthCamera,
      		target: player
			}));
      
			this.Manager.Add(player, 'player');
			
			return player;
		}//end spawn
  };//end PlayerSpawner


  
  

	return {
		PlayerSpawner: PlayerSpawner
	};
})();



//