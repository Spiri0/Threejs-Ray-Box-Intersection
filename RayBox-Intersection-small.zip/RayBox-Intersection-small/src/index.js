import {Main} from "./main.js";

let _APP = null;

window.addEventListener('DOMContentLoaded', async () => {
	_APP = new Main();
	await _APP._Initialize();
});