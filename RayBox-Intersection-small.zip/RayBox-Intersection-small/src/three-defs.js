import * as THREE from "../resources/libs/three/build/three.module.js";
import { OrbitControls } from '../resources/libs/three/examples/jsm/controls/OrbitControls.js';

import { RenderPass } from '../resources/libs/three/examples/jsm/postprocessing/RenderPass.js'; 
import { ShaderPass } from '../resources/libs/three/examples/jsm/postprocessing/ShaderPass.js';
import { EffectComposer } from '../resources/libs/three/examples/jsm/postprocessing/EffectComposer.js'; 

import {CopyShader} from '../resources/libs/three/examples/jsm/shaders/CopyShader.js'; 
import {FXAAShader} from '../resources/libs/three/examples/jsm/shaders/FXAAShader.js'; 

import { ColladaLoader } from '../resources/libs/three/examples/jsm/loaders/ColladaLoader.js';
import {GLTFLoader} from '../resources/libs/three/examples/jsm/loaders/GLTFLoader.js'; 
import * as SkeletonUtils from '../resources/libs/three/examples/jsm/utils/SkeletonUtils.js';

import WebGL from '../resources/libs/three/examples/jsm/WebGL.js';
import { Water } from '../resources/libs/three/examples/jsm/objects/Water.js'; 



export {THREE, OrbitControls, RenderPass, ShaderPass, EffectComposer, CopyShader, FXAAShader, GLTFLoader, SkeletonUtils, WebGL, Water, ColladaLoader};