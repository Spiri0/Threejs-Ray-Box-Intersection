import {threejs_component} from './threejs-component.js';
import {entity_manager} from './entity-manager.js';
import {entity} from './entity.js';
import {load_controller} from './load-controller.js';
import {spawners} from './spawners.js';
import {THREE} from './three-defs.js';
import {clouds} from "./clouds.js";

import {player_input} from './player-input.js';




class Main {
	constructor(){
	}

	async _Initialize() {   
		this.entityManager_ = new entity_manager.EntityManager();
		this.OnGameStarted_();
	}

	async OnGameStarted_() {
		await this.LoadControllers_();
		this.previousRAF_ = null;
		this.RAF_();
	}


  async LoadControllers_() {
  
		const threejs = new entity.Entity();
    	threejs.AddComponent(new threejs_component.ThreeJSController());
    	this.entityManager_.Add(threejs, 'threejs');

    	this.scene_ = threejs.GetComponent('ThreeJSController').scene_;
    	this.camera_ = threejs.GetComponent('ThreeJSController').camera_;
    	this.threejs_ = threejs.GetComponent('ThreeJSController');

    const l = new entity.Entity();
    l.AddComponent(new load_controller.LoadController());
    this.entityManager_.Add(l, 'loader');


		const basicParams = {
			scene: this.scene_,
			camera: this.camera_,
		};

		const spawner = new entity.Entity();	
		
		//Player
		spawner.AddComponent(new spawners.PlayerSpawner({
			scene: this.threejs_.scene_,
			camera: this.threejs_.camera_,
			depthCamera: this.threejs_.depthCamera_,
		}));

		this.entityManager_.Add(spawner, 'spawners');
		
		spawner.GetComponent('PlayerSpawner').Spawn();


		const geometry = new THREE.SphereGeometry( 6350000, 128, 64 ); 
		const material = new THREE.MeshBasicMaterial( { color: 0xff0000 } ); 
		const sphere = new THREE.Mesh( geometry, material ); 	
		this.scene_.add( sphere );


		const cloud = new entity.Entity();
		cloud.AddComponent(
			new clouds.Clouds({
				camera: this.camera_,
				scene: this.scene_,
				threejs: this.threejs_,
     	}));
		this.entityManager_.Add(cloud, 'clouds');


	}
	

	RAF_() {
	
    requestAnimationFrame((t) => {
      if (this.previousRAF_ === null) {
        this.previousRAF_ = t;
      } else {
        this.Step_(t - this.previousRAF_);
        this.threejs_.Render();
        this.previousRAF_ = t;
      }

      setTimeout(() => {
        this.RAF_();
      }, 1);
    });
  }
  
  
  Step_(timeElapsed) { 
    const timeElapsedS = Math.min(1.0 / 30.0, timeElapsed * 0.001);
    
    this.entityManager_.Update(timeElapsedS, 0);
    this.entityManager_.Update(timeElapsedS, 1);
  }


}



export {Main}

//