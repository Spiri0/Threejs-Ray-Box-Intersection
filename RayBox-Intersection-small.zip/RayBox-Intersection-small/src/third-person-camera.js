import {THREE} from './three-defs.js';
import {entity} from './entity.js';


export const third_person_camera = (() => {
  
	class ThirdPersonCamera extends entity.Component {
		constructor(params) {
			super();

			this.params_ = params;
			this.camera_ = params.camera;
			this.depthCamera_ = params.depthCamera;

			this.currentPosition_ = new THREE.Vector3();
			//this.SetPass(1);

			this.matrix = new THREE.Matrix4();
			this.x = new THREE.Vector3();
			this.y = new THREE.Vector3();
			this.z = new THREE.Vector3();
      
			this.fracx = 0;
			this.fracy = 0;
			this.fracz = 0;
      
		}

		_CalculateIdealOffset() {
			const offsetY = 2;
			const offsetZ = 7;
			const idealOffset = new THREE.Vector3(0, offsetY, offsetZ);
      
			const input = this.Parent.Attributes.InputCurrent;


			this.fracx = this._lerp (this.fracx, 0.04* input.axis1Side, 0.06);
			this.fracy = this._lerp (this.fracy, -0.025* input.axis1Up, 0.06);
			this.fracz = this._lerp (this.fracz, -0.02* input.axis1Forward, 0.06);
			this.fracz = this._lerp (this.fracz, -0.06* input.space, 0.06);
    

			this.Parent.components_.RenderComponent.group_.matrixWorld.extractBasis(this.x, this.y, this.z);

			idealOffset.applyQuaternion(this.params_.target.Quaternion);
			idealOffset.add(this.params_.target.Position);	
			
			return idealOffset;
      
		}

		_lerp (start, end, amt){
			return (1-amt)*start+amt*end
		}


		Update(timeElapsed) {
    
			const idealOffset = this._CalculateIdealOffset();

			const t1 = 1.0 - Math.pow(0.01, timeElapsed);
			const t2 = 1.0 - Math.pow(0.05, timeElapsed);

			//this.currentPosition_.lerp(idealOffset, t1);

			this.currentPosition_ = idealOffset;
		
			this.currentPosition_.add(this.x.multiplyScalar(this.fracx));
			this.currentPosition_.add(this.y.multiplyScalar(this.fracy));
			this.currentPosition_.add(this.z.multiplyScalar(this.fracz));
			
			//document.getElementById("testfield1").value = Object.keys(this.params_.target);
		
			this.camera_.position.copy(this.currentPosition_);
			this.camera_.quaternion.slerp(this.params_.target.Quaternion, t2);
      
			this.depthCamera_.position.copy(this.currentPosition_);
			this.depthCamera_.quaternion.slerp(this.params_.target.Quaternion, t2);
      
		}
	};//end class

	return {
		ThirdPersonCamera: ThirdPersonCamera
	};

})();




//