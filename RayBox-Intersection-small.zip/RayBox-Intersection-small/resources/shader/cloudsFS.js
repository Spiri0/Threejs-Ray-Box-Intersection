export const cloudsFS = `


	#define PI 3.141592653589793238
	#define FLT_MAX 3.402823466e+38

	precision highp float; 
	precision highp int;
	precision highp sampler2D;
	precision highp sampler3D;
		
	in vec2 vUv;	
	out vec4 outColor;	
	
	
	uniform sampler3D cloud;
	uniform sampler3D worley;
	uniform sampler2D weather;
	uniform sampler2D tDiffuse;
	uniform sampler2D tDepth;
	uniform sampler3D perlinWorley;
	
	uniform float cameraNear;
	uniform float cameraFar;
	uniform vec3 cameraPos;
	uniform vec3 cameraForward;
	uniform vec3 planetPos;
	uniform mat4 inverseProjection;
	uniform mat4 inverseView;
	uniform float planetRadius;
	uniform float logDepthBufFC;
	uniform vec3 sunPos;
	uniform vec3 sunColor;
	uniform float oceanRadius;
	uniform float cloudsInnerRadius;
	uniform float cloudsOuterRadius;
	

	//-----------------functions---------------------

	vec3 computeWorldPosition(){ 
	
		float z = texture(tDepth, vUv).x;
	
		vec4 posCLIP = vec4(vec3(vUv - 0.5, z - 0.5) * 2.0, 1.0); 		
		vec4 posVS = inverseProjection * posCLIP;
		posVS = vec4(posVS.xyz / posVS.w, 1.0);
		vec4 posWS = inverseView * posVS;	
		
		return posWS.xyz;
	}
	

	vec2 hitBox(vec3 orig, vec3 dir, vec3 boxMin, vec3 boxMax) {
		vec3 inv_dir = 1.0 / dir;
		vec3 tmin_tmp = ( boxMin - orig ) * inv_dir;
		vec3 tmax_tmp = ( boxMax - orig ) * inv_dir;	
		vec3 tmin = min( tmin_tmp, tmax_tmp );
		vec3 tmax = max( tmin_tmp, tmax_tmp );
		
		float tNear = max( tmin.x, max( tmin.y, tmin.z ) );
		float tFar = min( tmax.x, min( tmax.y, tmax.z ) );
		
		return vec2( tNear, tFar );
	}


	bool sampleWeather(vec3 pos) { 	
	
		float theta = atan(pos.y/sqrt(pos.x * pos.x + pos.z * pos.z));
		float phi = 0.0;
		
		if(pos.x > 0.){phi = atan(pos.z/pos.x);}
		if(pos.x == 0.){phi = sign(pos.z) * PI/2.0;}
		if(pos.x < 0. && pos.z >= 0.){phi = atan(pos.z/pos.x) + PI;}
		if(pos.x < 0. && pos.z < 0.){phi = atan(pos.z/pos.x) - PI;}
			
		float u = phi/PI*0.5+0.5;
		float v = 0.5 - theta/PI;

		vec3 weatherMap = texture(weather, vec2(u, v)).rgb;
		if(weatherMap.r < 0.1){
			return false;
		}
		else{
			return true;				
		}
	}


	vec4 traceClouds(vec3 origin, vec3 dir, vec3 start, vec3 stop, vec3 sunDir){
	
		float trace = 0.;
	
	
		if(sampleWeather(start)){
			trace = 1.;
		}
		else{
			trace = 0.;
		}
	
		return vec4(1.) * trace;
	
	}


	vec4 scatterClouds(vec3 rayOrigin, vec3 rayDir, vec3 worldPos, vec3 sunDir){

		vec4 trace = vec4(0.);

		vec3 boxMin = vec3(1000., 1000., cloudsInnerRadius - 1.);
		vec3 boxMax = vec3(-1000., -1000., cloudsOuterRadius + 1.);
	
		vec2 intersect = hitBox(rayOrigin, rayDir, boxMin, boxMax);
		intersect.x = max(0., intersect.x);

		if(intersect.y > 0. && intersect.y > intersect.x){
	
			trace = traceClouds(
				rayOrigin, 
				rayDir, 
				rayOrigin + intersect.x * rayDir, 
				rayOrigin + intersect.y * rayDir, 
				sunDir
			);
		}
		
		return trace;
	}


	
	void main() {

		vec3 diffuse = texture(tDiffuse, vUv).rgb;
		vec3 cloudss = texture(cloud, vec3(vUv, .2)).rgb;
		vec3 worleys = texture(worley, vec3(vUv, .2)).rgb;
		vec3 weather = texture(weather, vUv).rgb;
				
		vec3 posWS = computeWorldPosition();
		vec3 cameraDirection = normalize(posWS - cameraPos);
		vec3 sunDir = normalize(planetPos - sunPos);
		

		vec4 trace = scatterClouds(cameraPos, cameraDirection, posWS, sunDir);

		outColor = trace;

		//outColor = vec4(posWS, 1.);
		//outColor = vec4(cloudss, 1.);
		//outColor = vec4(worleys, 1.);
		//outColor = vec4(weather, 1.);		
		//outColor = vec4(vec3(1.,0.,0.), 1.);

	}`;
	
	
	//*******************************************************************************
	//*******************************************************************************
	
	
	
	